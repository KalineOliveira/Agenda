
package classes;

import java.sql.*;
import java.util.concurrent.ExecutionException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.management.Query;
import javax.swing.JOptionPane;


public class ConexaoBD {
    
    
    public static final String DRIVE = "com.mysql.jdbc.Driver";
    public static final String HOST = "127.0.0.1:3306";
    public static final String BASE = "agenda";
    public static final String USER = "root";
    public static final String PASS = "123";

    Connection conexao;
    
    
    public void conectar() throws SQLException{
       try{
           Class.forName(DRIVE);
           Connection con = DriverManager.getConnection("jdbc:mysql://"+HOST+"/"+BASE+"?user="+USER+"&password="+PASS+"");
           
           this.conexao = con;
           
          // JOptionPane.showMessageDialog(null,"Conectado!");
           
        }catch(ClassNotFoundException ex){
            Logger.getLogger(ConexaoBD.class.getName()).log(Level.SEVERE,null,ex);
        }     
       
    }
  
    public ResultSet consultar(String query) throws SQLException{
      Statement ps = this.conexao.createStatement();
      ResultSet rs = ps.executeQuery(query);
      return rs;
      
  }
          
    public int atualizar (String query)throws SQLException{
      Statement ps = this.conexao.createStatement();
      int rs = ps.executeUpdate(query);
      return rs;
    }
    
    public void desconectar()throws SQLException{
        this.conexao.close();
    }
}
