
package classes;

import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;

public class Usuario {
    
    private ConexaoBD conexao = new ConexaoBD();
    private String nome;
    private String senha;
    private ResultSet consulta;
    private int codigo;
    
    public boolean Login(String nome,String senha){
        boolean sessao = false;
        try {
            String query = "select nome,senha from usuario " + "where nome = '"+nome+ "' and senha='"
                    +senha+"'";
            
            getConexao().conectar();
            setConsulta(getConexao().consultar(query));
            
            if(getConsulta()!=null){
                while (consulta.next()){
                    Usuario Login = new Usuario();
                    Login.setNome(consulta.getString(1));
                    Login.setSenha(consulta.getString(2));
                    sessao = true ;
                }
            }
            
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Erro na Consulta");
        }
    return sessao;
    }
  

    /**
     * @return the conexao
     */
    public ConexaoBD getConexao() {
        return conexao;
    }

    /**
     * @param conexao the conexao to set
     */
    public void setConexao(ConexaoBD conexao) {
        this.conexao = conexao;
    }

    /**
     * @return the nome
     */
    public String getNome() {
        return nome;
    }

    /**
     * @param nome the nome to set
     */
    public void setNome(String nome) {
        this.nome = nome;
    }

    /**
     * @return the senha
     */
    public String getSenha() {
        return senha;
    }

    /**
     * @param senha the senha to set
     */
    public void setSenha(String senha) {
        this.senha = senha;
    }

    /**
     * @return the consulta
     */
    public ResultSet getConsulta() {
        return consulta;
    }

    /**
     * @param consulta the consulta to set
     */
    public void setConsulta(ResultSet consulta) {
        this.consulta = consulta;
    }

    /**
     * @return the codigo
     */
    public int getCodigo() {
        return codigo;
    }

    /**
     * @param codigo the codigo to set
     */
    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }
    
}
