
package formulario;

import classes.ConexaoBD;
import classes.*;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import javax.swing.plaf.RootPaneUI;

public class Contatos {
    
    String ent;
    String nome;
    String telefone;
    String celular1;
    String celular2;
    String endereco;
    ResultSet consulta;
      int cogigo;
      
 void setAtributos (String nome, String telefone, String celular1, String celular2, String endereco){
     
     this.nome = nome;
     this.telefone = telefone;
     this.celular1 = celular1;
     this.celular2 = celular2;
     this.endereco = endereco;
 }  
 
 void setCodigo (int cod){
     this.cogigo = cod;
 }
 
 void consulta (ConexaoBD conexao) throws SQLException{
     String sql = "select* from contatos";
     conexao.conectar();
     consulta = conexao.consultar(sql);     
    
 }
 
 void incluir(ConexaoBD conexao)throws SQLException{
     //JOptionPane.showMessageDialog(null, "INSERT INTO cadmaterial,quatMaterial,descMaterial,codMaterial,data) Value('" + ;
    String sql = "INSERT INTO contatos (nome,telefone,celular1,celular2,endereco) VALUES ('"+this.nome+"','"+this.telefone+"','"+
            this.celular1+"','"+this.celular2+"','"+this.endereco+"')";
    
    // FAZ A CONEXÃO COM O BANCO DE DADOS E ABRE OS MESMO
    conexao.conectar();
    //ATUALIZA O BANCO DE DADOS COM A LINHA SQL
    
    int i = conexao.atualizar(sql);
    conexao.desconectar();
               
 }
  void alterar(ConexaoBD conexao)throws SQLException{
      String sql = "update contatos set nome = '"+this.nome+"',telefone ='"+this.telefone+"',celular1 ='"+this.celular1+"',celular2 ='"
              +this.celular2+"',endereco ='"+this.endereco+"' where idcodigo = "+this.cogigo;
      
      // FAZ A CONEXÃO COM O BANCO DE DADOS E ABRE OS MESMO
    conexao.conectar();
    //ATUALIZA O BANCO DE DADOS COM A LINHA SQL
    
    int i = conexao.atualizar(sql);
    conexao.desconectar();
              
  }
 
   void deletar(ConexaoBD conexao)throws SQLException{
           // 0 = sim/1 = não/2 = cancelar
           String sql = "delete from contatos where id ="+this.cogigo;
  
         // FAZ A CONEXÃO COM O BANCO DE DADOS E ABRE OS MESMO
        conexao.conectar();
        //ATUALIZA O BANCO DE DADOS COM A LINHA SQL
    
         int i = conexao.atualizar(sql);
         conexao.desconectar();
   }
      
  void locaContatoNome (ConexaoBD conexao)throws SQLException{
     this.ent = ent;
     String sql = "select* from contatos where nome like '%"+this.ent+"%'";
     conexao.conectar();
     consulta = conexao.consultar(sql);  
     
 }
  
 void locaContatoEnt (ConexaoBD conexao)throws SQLException{
     this.ent = ent;
     String sql = "select* from contatos where nome like '%"+this.ent+"%'";
     conexao.conectar();
     consulta = conexao.consultar(sql);  
   
}
 void locaContatosTelefone (ConexaoBD conexao)throws SQLException{
     this.ent = ent;
     String sql = "select* from contatos where nome like '%"+this.ent+"%'";
     conexao.conectar();
     consulta = conexao.consultar(sql);  
 
 
}
}
