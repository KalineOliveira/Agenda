/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/*
 * FormCadContato.java
 *
 * Created on 16/11/2023, 08:26:17
 */
package formulario;

import classes.*;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author 2° ano
 */
public class FormCadContato extends javax.swing.JFrame {
    Contatos contato = new Contatos();
    ConexaoBD conexao = new ConexaoBD();


    
    
    public FormCadContato() {
        initComponents();
    }

    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        btSalvar = new javax.swing.JButton();
        btAlterar = new javax.swing.JButton();
        btDeletar = new javax.swing.JButton();
        jPanel2 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        txtEndereco = new javax.swing.JTextField();
        txtCel1 = new javax.swing.JTextField();
        txtNome = new javax.swing.JTextField();
        txtCel2 = new javax.swing.JTextField();
        txtTel = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        tbContatos = new javax.swing.JTable();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(null);

        jPanel1.setBackground(new java.awt.Color(153, 204, 255));
        jPanel1.setLayout(null);

        btSalvar.setFont(new java.awt.Font("Times New Roman", 1, 12));
        btSalvar.setText("Salva");
        btSalvar.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        btSalvar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btSalvarActionPerformed(evt);
            }
        });
        jPanel1.add(btSalvar);
        btSalvar.setBounds(20, 10, 60, 20);

        btAlterar.setFont(new java.awt.Font("Times New Roman", 1, 12));
        btAlterar.setText("Alterar");
        btAlterar.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        btAlterar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btAlterarActionPerformed(evt);
            }
        });
        jPanel1.add(btAlterar);
        btAlterar.setBounds(160, 10, 60, 20);

        btDeletar.setFont(new java.awt.Font("Times New Roman", 1, 12));
        btDeletar.setText("Deletar");
        btDeletar.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        btDeletar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btDeletarActionPerformed(evt);
            }
        });
        jPanel1.add(btDeletar);
        btDeletar.setBounds(293, 10, 80, 20);

        getContentPane().add(jPanel1);
        jPanel1.setBounds(0, 330, 480, 40);

        jPanel2.setBackground(new java.awt.Color(153, 204, 255));
        jPanel2.setLayout(null);

        jLabel1.setFont(new java.awt.Font("Times New Roman", 1, 14));
        jLabel1.setText("Catastro de Contatos");
        jPanel2.add(jLabel1);
        jLabel1.setBounds(10, 10, 150, 30);

        getContentPane().add(jPanel2);
        jPanel2.setBounds(0, 0, 480, 50);

        jLabel2.setFont(new java.awt.Font("Times New Roman", 1, 14));
        jLabel2.setText("Telefone:");
        getContentPane().add(jLabel2);
        jLabel2.setBounds(10, 260, 90, 17);

        jLabel3.setFont(new java.awt.Font("Times New Roman", 1, 14));
        jLabel3.setText("Nome:");
        getContentPane().add(jLabel3);
        jLabel3.setBounds(10, 60, 60, 10);

        jLabel4.setFont(new java.awt.Font("Times New Roman", 1, 14));
        jLabel4.setText("Endereço:");
        getContentPane().add(jLabel4);
        jLabel4.setBounds(10, 110, 100, 20);

        jLabel5.setFont(new java.awt.Font("Times New Roman", 1, 14));
        jLabel5.setText("Celular 01:");
        getContentPane().add(jLabel5);
        jLabel5.setBounds(10, 160, 90, 17);

        jLabel6.setFont(new java.awt.Font("Times New Roman", 1, 14));
        jLabel6.setText("Celular 02:");
        getContentPane().add(jLabel6);
        jLabel6.setBounds(10, 210, 100, 17);

        txtEndereco.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtEnderecoActionPerformed(evt);
            }
        });
        getContentPane().add(txtEndereco);
        txtEndereco.setBounds(10, 130, 370, 20);

        txtCel1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtCel1ActionPerformed(evt);
            }
        });
        getContentPane().add(txtCel1);
        txtCel1.setBounds(10, 180, 160, 20);

        txtNome.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtNomeActionPerformed(evt);
            }
        });
        getContentPane().add(txtNome);
        txtNome.setBounds(10, 80, 370, 20);

        txtCel2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtCel2ActionPerformed(evt);
            }
        });
        getContentPane().add(txtCel2);
        txtCel2.setBounds(10, 230, 160, 20);

        txtTel.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtTelActionPerformed(evt);
            }
        });
        getContentPane().add(txtTel);
        txtTel.setBounds(10, 280, 160, 20);

        tbContatos.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        tbContatos.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tbContatosMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tbContatos);

        getContentPane().add(jScrollPane1);
        jScrollPane1.setBounds(180, 180, 220, 110);

        java.awt.Dimension screenSize = java.awt.Toolkit.getDefaultToolkit().getScreenSize();
        setBounds((screenSize.width-424)/2, (screenSize.height-406)/2, 424, 406);
    }// </editor-fold>//GEN-END:initComponents

    void atualizarTabelaContato(){
    try{
        tbContatos.setModel(new javax.swing.table.DefaultTableModel(
                new Object[][]{}, new String []{"ID","Telefone","Celular1","Celular2",
                    "Endereço"} ));
        DefaultTableModel tabela = (DefaultTableModel) tbContatos.getModel();
        while (contato.consulta.next()) {
                int cod = contato.consulta.getInt("idCodigo");
                String nome = contato.consulta.getString("nome");
                String telefone = contato.consulta.getString("telefone");
                String celular1 = contato.consulta.getString("celular1");
                String celular2 = contato.consulta.getString("celular2");
                String endereco = contato.consulta.getString("endereco");
                tabela.addRow(new Object []{cod,nome,telefone,celular1,celular2,endereco});
            }
           
} catch (Exception e ){
}
    }
    
private void txtEnderecoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtEnderecoActionPerformed
// TODO add your handling code here:
}//GEN-LAST:event_txtEnderecoActionPerformed

private void txtCel1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtCel1ActionPerformed
// TODO add your handling code here:
}//GEN-LAST:event_txtCel1ActionPerformed

private void txtNomeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtNomeActionPerformed
// TODO add your handling code here:
}//GEN-LAST:event_txtNomeActionPerformed

private void txtCel2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtCel2ActionPerformed
// TODO add your handling code here:
}//GEN-LAST:event_txtCel2ActionPerformed

private void txtTelActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtTelActionPerformed
// TODO add your handling code here:
}//GEN-LAST:event_txtTelActionPerformed


private void btSalvarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btSalvarActionPerformed
   int flag = JOptionPane.showConfirmDialog (null, "Deseja salvar?");
    if (flag == 0){
       try {
           
        contato.setAtributos(txtNome.getText(), txtTel.getText(), txtCel1.getText(), txtCel2.getText(),txtEndereco.getText());
        contato.incluir(conexao);
        contato.consulta(conexao);
        atualizarTabelaContato();
        JOptionPane.showMessageDialog(rootPane, "Contato inserido com sucesso!");
             
       } catch (Exception e){
           
        JOptionPane.showMessageDialog(rootPane, "Contato não inserido!");

       }
    }
       
       
         
}//GEN-LAST:event_btSalvarActionPerformed



private void btAlterarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btAlterarActionPerformed

    int flag = JOptionPane.showConfirmDialog (null, "Deseja excluir?");
    if (flag == 0){
       try {
           
        contato.deletar(conexao);
        contato.consulta(conexao);
        atualizarTabelaContato();
        JOptionPane.showMessageDialog(rootPane, "Deletado com sucesso!");
             
       } catch (Exception e){
           
        JOptionPane.showMessageDialog(rootPane, "Impossível deletar o campo!");

       }
    }
       
    
}//GEN-LAST:event_btAlterarActionPerformed

private void btDeletarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btDeletarActionPerformed
  int flag = JOptionPane.showConfirmDialog (null, "Deseja alterar?");
    if (flag == 0){
       try {
           
        contato.setAtributos(txtNome.getText(), txtTel.getText(), txtCel1.getText(), txtCel2.getText(), txtEndereco.getText());
        contato.deletar(conexao);
        contato.consulta(conexao);
        atualizarTabelaContato();
        JOptionPane.showMessageDialog(rootPane, "Alterado com sucesso!");
             
       } catch (Exception e){
           
        JOptionPane.showMessageDialog(rootPane, "Impossível alterar o campo!");

       }
    }                  
    
    
}//GEN-LAST:event_btDeletarActionPerformed

private void tbContatosMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tbContatosMouseClicked
                                      
        // TODO add your handling code here:
        contato.setCodigo((Integer)tbContatos.getValueAt(tbContatos.getSelectedRow(),0));
        txtNome.setText((String)tbContatos.getValueAt(tbContatos.getSelectedRow(),1));
        txtTel.setText((String)tbContatos.getValueAt(tbContatos.getSelectedRow(),2));
        txtCel1.setText((String)tbContatos.getValueAt(tbContatos.getSelectedRow(),3));
        txtCel2.setText((String)tbContatos.getValueAt(tbContatos.getSelectedRow(),4));
        txtEndereco.setText((String)tbContatos.getValueAt(tbContatos.getSelectedRow(),5));
                     
}//GEN-LAST:event_tbContatosMouseClicked

    
    public static void main(String args[]) {
       
        java.awt.EventQueue.invokeLater(new Runnable() {

            public void run() {
                new FormCadContato().setVisible(true);
            }
        });
    }
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btAlterar;
    private javax.swing.JButton btDeletar;
    private javax.swing.JButton btSalvar;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable tbContatos;
    private javax.swing.JTextField txtCel1;
    private javax.swing.JTextField txtCel2;
    private javax.swing.JTextField txtEndereco;
    private javax.swing.JTextField txtNome;
    private javax.swing.JTextField txtTel;
    // End of variables declaration//GEN-END:variables
}
